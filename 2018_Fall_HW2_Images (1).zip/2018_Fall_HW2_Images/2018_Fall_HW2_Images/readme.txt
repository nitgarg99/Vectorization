Example images, which are in the one channel or grayscale format. 
  They are as follows with dimensions and brief description
   image1.raw -> 352x288 shows a foreman
   image2.raw -> 352x288 shows a golf playing scene
   image3.raw -> 352x288 shows a man in swimming pool
   image4.raw -> 352x288 shows a construction site

You can use the same reference code we provided to display images.
The .rgb are the color images with three channels - 352x288 red bytes, followed by 352x288 green, followed by 352x288 blue